<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php require("inc/links.php") ?>
  <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
  <title><?php echo $setting_r['site_title'] ?></title>

</head>
<style>
  /* .availabilty-form {
    margin-top: -50px;
    z-index: 2;
    position: relative;
  } */
  .wrapper {
    margin-top: 0;
    padding: 0;
    margin-bottom: 0;
}
.collapsible {
    max-width: 100%;
    overflow: hidden;
    font-weight: 500;
}
.collapsible input{
    display: none;
}
.collapsible label {
    position:relative;
    font-weight: 600;
    background: #1c6b61;
    box-shadow: 0 5px 11px 0 rgba(0,0,0,.1), 0 4px 11px 0 rgba(0,0,0,.08);
    color:ffffff;
    display: block;
    margin-bottom: 10px;
    cursor: pointer;
    padding: 15px;
    border-radius: 4px;
    z-index: 1;
}
.collapsible label::before {
    content: "";
    position: absolute;
    padding-right: 30px;
    top: 0;
    width: 18px;
    height: 18px;
    background: url(circle-info-solid.svg) no-repeat 0 0;
}
.collapsible label:after {
    content: "";
    position: absolute;
    right: 15px;
    top: 18px;
    width: 18px;
    height: 18px;
    background: url(circle-chevron-down-solid.svg) no-repeat 0 0;
    transition: all 0.3s ease;
}
.collapsible input:checked + label:after {
    transform: rotate(180deg);
}
.collapsible-text {
    max-height: 1px;
    overflow: hidden;
    border-radius: 4px;
    line-height: 1.4;
    position: relative;
    top: -100%;
    opacity: 0.5;
}
.collapsible input:checked ~ .collapsible-text {
    max-height: 300px;
    padding-bottom: 25px;
    background: #fff;
    box-shadow: 0 5px 11px 0 rgba(0,0,0,.1), 0 4px 11px 0 rgba(0,0,0,.08);
    opacity: 1;
    top: 0;
}
.collapsible-text p{
    margin-bottom: 10px;
    padding: 15px 15px 0;
    color:  #1c1c6b;
}
</style>

<body class="bg-light">
  <?php require('inc/header.php') ?>
  <div class="wrapper ">
      <div class="collapsible">
          <input type="checkbox" id="collapsible-head">
          <label for="collapsible-head">
              Important
          </label>
          <div class="collapsible-text">
              <p>We only provide the facilities that we can, we do neither interfere in the policies and regulations of any hotel nor alter any of the amenities of provided by any hotel. all the packages, deals and availability we do provide are all according to the features provided by hotel.</p>
          </div>
   
    </div>

  <!-- slider --> 
  <div class="container-fluid px-lg-0 ">
    <div class="swiper Swiper-container">
      <div class="swiper-wrapper">
        <?php
        $res = selectAll('carousel');
        while ($row = mysqli_fetch_assoc($res)) {
          $path = CAROUSEL_IMG_PATH;
          echo <<<data
        <div class="swiper-slide">
          <img src="$path$row[image]" class="w-100 d-block " height="450px" >
        </div>
           
        data;
        }
        ?>
      </div>
    </div>
  </div>
  <!-- check-->
  <div class="container availabilty-form">
    <div class="row">
    
</div>
    </div>
  </div>
  <!-- rooms -->
  <h2 class=".mt-5 pt-4 mb-4 text-center fw-bold h-font">OUR ROOMS</h2>
  <div class="container">
    <div class="row">
      <?php
      $room_res = select("SELECT * FROM `rooms` WHERE `status`=? AND `removed`=?  ORDER BY `id` DESC LIMIT 3", [1, 0], 'ii');
      while ($room_data = mysqli_fetch_assoc($room_res)) {
        // get features of room
        $fea_q = mysqli_query($con, "SELECT f.name FROM `features` f 
                          INNER JOIN `room_features` rfea ON f.id = rfea.features_id WHERE 
                           rfea.room_id = '$room_data[id]'");


        $features_data = "";
        while ($fea_row = mysqli_fetch_assoc($fea_q)) {
          $features_data .= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>$fea_row[name]
                            </span>";
        }


        // get facilities of room
        $fac_q = mysqli_query($con, "SELECT f.name FROM `facilities` f 
                        INNER JOIN `room_facilities` rfac ON f.id = rfac.facilities_id
                        WHERE rfac.room_id = '$room_data[id]'");


        $facilities_data = "";
        while ($fac_row = mysqli_fetch_assoc($fac_q)) {
          $facilities_data .= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>$fac_row[name]
                            </span>";
        }

        // get thumbnail of image

        $room_thumb = ROOMS_IMG_PATH . "thumbnail.jpg";
        $thumb_q = mysqli_query($con, "SELECT * FROM `room_images` 
                        WHERE `room_id` = '$room_data[id]' AND `thumb`='1'");


        if (mysqli_num_rows($thumb_q) > 0) {
          $thumb_res = mysqli_fetch_assoc($thumb_q);
          $room_thumb = ROOMS_IMG_PATH . $thumb_res['image'];
        }

        $book_btn ="";
        if(!$setting_r['shutdown']){
          $login=0;
          if(isset($_SESSION['login']) && $_SESSION['login']==true){
            $login=1;
          }
          $book_btn= "<button onclick='checkLoginToBook($login,$room_data[id])' class='btn btn-sm text-white custom-bg shadow-none'>Book Now</button>";


        }
        



        // print room card

        echo <<< data
                              <div class="col-lg-4 col-md-6 my-3">
                              <div class="card border-0 shadow" style="max-width:350px; margin: auto;">
                                <img src="$room_thumb" class="card-img-top" alt="...">
                                <div class="card-body">
                                  <h5>$room_data[name]</h5>
                                  <h6 class="mb-4">/-$room_data[price]</h6>
                                  <div class="features mb-4">
                                    <h6 class="mb-1">Features</h6>
                                    $features_data 
                                   
                                  </div>
                                  <div class="facilities mb-4">
                                    <h6 class="mb-1">Facilities</h6>
                                    $facilities_data
                                  </div>
                                  <div class="guest mb-4">
                                    <h6 class="mb-1">Guest</h6>
                                    <span class="badge rounded-pill bg-light text-dark text-wrap"> $room_data[adult] Adult</span>
                                    <span class="badge rounded-pill bg-light text-dark text-wrap">$room_data[children]</span>
                                  </div>
                                  <div class="rating mb-4">
                                    <h6 class="mb-1">Rating</h6>
                                    <span class="badge rounded-pill bg-light">
                                      <i class="bi bi-star-fill text-warning"></i>
                                      <i class="bi bi-star-fill text-warning"></i>
                                      <i class="bi bi-star-fill text-warning"></i>
                                      <i class="bi bi-star-fill text-warning "></i>
                                      <i class="bi bi-star-fill text-warning "></i>
                                    </span>
                                  </div>
                                  <div class="d-flex justify-content-evenly">
                                    $book_btn
                                    
                                    <a href="room_details.php?id=$room_data[id]" class="btn btn-sm btn-outline-dark  shadow-none">more Detail</a>
                                  </div>
                                </div>
                              </div>
                            </div>








                                
                          data;
      }





      ?>




      <div class="col-lg-12 text-center mt-5">
        <a href="rooms.php" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">More Rooms</a>
      </div>
    </div>
  </div>

  <!-- facilities -->
  <h2 class=".mt-5 pt-4 mb-4 text-center fw-bold h-font">OUR Facilities</h2>
  <div class="container">
    <div class="row justify-content-evenly px-lg-0">
      <?php

      $res = mysqli_query($con, "SELECT * FROM `facilities`ORDER BY `id` DESC  LIMIT 5  ");

      $path = FACILITIES_IMG_PATH;

      while ($row = mysqli_fetch_assoc($res)) {
        echo <<<data
                <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
                <img src="$path$row[icon]" width="50px">
                <h5 class="mt-3">$row[name]</h5>
              </div>
              data;
      }

      ?>
      <div class="col-lg-12 text-center mt-5">
        <a href="facilities.php" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">More facilities</a>
      </div>
    </div>
  </div>


  <!-- test -->

  <h2 class=".mt-5 pt-4 mb-4 text-center fw-bold h-font">TESTIMONIALS</h2>


  <div class="container mt-5">
    <div class="swiper Swiper-test">
      <div class="swiper-wrapper mb-5">
        <div class="swiper-slide bg-white p-4">
          <div class="profile d-flex align-item-center mb-3">
            <img src="1.jpeg" width="30px">
            <h6 class="m-0 ms-2">Hamza Siddiqui</h6>
          </div>
          <p>
          They were extremely accommodating and allowed us to check in early at like 10am. We got to hotel super early and I didn’t wanna wait. So this was a big plus. The sevice was exceptional as well. Would definitely send a friend there.
          </p>
          <div class="rating">

            <i class="bi bi-star-fill text-warning"></i>
            <i class="bi bi-star-fill text-warning"></i>
            <i class="bi bi-star-fill text-warning"></i>
            <i class="bi bi-star-fill text-warning "></i>
            <i class="bi bi-star-fill text-warning "></i>

          </div>
        </div>
        <div class="swiper-slide bg-white p-4">
          <div class="profile d-flex align-item-center mb-3">
            <img src="2.jpeg" width="30px">
            <h6 class="m-0 ms-2">Maha Aamir</h6>
          </div>
          <p>
          The best hotel I’ve ever been privileged enough to stay at. Gorgeous building, and it only gets more breathtaking when you walk in. High quality rooms (there was even a tv by the shower), and high quality service. Also, they are one of few hotels that allow people under 21 to book a reservation.
          </p>
          <div class="rating">

            <i class="bi bi-star-fill text-warning"></i>
            <i class="bi bi-star-fill text-warning"></i>
            <i class="bi bi-star-fill text-warning"></i>
            <i class="bi bi-star-fill text-warning "></i>
            <i class="bi bi-star-half text-warning "></i>

          </div>
        </div>
        <div class="swiper-slide bg-white p-4">
          <div class="profile d-flex align-item-center mb-3">
            <img src="3.jpeg" width="30px">
            <h6 class="m-0 ms-2">Fariha Arif</h6>
          </div>
          <p>
          The hotel was wonderful. It was even better than expected. The price was amazing. There were great restaurants within walking distance. Would definitely stay there again.
          </p>
          <div class="rating">

            <i class="bi bi-star-fill text-warning"></i>
            <i class="bi bi-star-fill text-warning"></i>
            <i class="bi bi-star-fill text-warning"></i>
            <i class="bi bi-star-fill text-warning "></i>
            
          </div>
        </div>

      </div>
      <div class="swiper-pagination"></div>
    </div>
    <div class="col-lg-12 text-center mt-5">
      <a href="about.php" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">know more</a>
    </div>
  </div>
  </div>

  <!-- reah -->


  <h2 class=".mt-5 pt-4 mb-4 text-center fw-bold h-font">Reach Us</h2>
  <div class="container">
    <div class="row">
      <div class="col-lg-8 mb-lg-0 bg-white rounded">
        <iframe class="w-100 rounded" height="320" src="<?php echo $contact_r['iframe'] ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

      </div>
      <div class="col-lg-4 ">
        <div class="bg-white p-4 rounded">
          <h5>call us</h5>
          <a href="+<?php echo $contact_r['pn1'] ?>" class="d-inline-block mb-2 text-decoration-none text-dark">
            <i class="bi bi-telephone-fill"></i> +<?php echo $contact_r['pn1'] ?></a>
          <br>
          <?php
          if ($contact_r['pn2'] != '') {
            echo <<<data
              <a href="+$contact_r[pn2]" class="d-inline-block mb-2 text-decoration-none text-dark">
              <i class="bi bi-telephone-fill"></i> +$contact_r[pn2]</a>

              data;
          }
          ?>

        </div>
        <div class="bg-white p-4 rounded ">
          <h5>Follow us</h5>
          <?php
          if ($contact_r['tw'] != '') {
            echo <<<data
            <a href="$contact_r[tw]" class="d-inline-block mb-3  text-dark">
            <span class="badge bg-light text-dark fs-6 p-2">
              <i class="bi bi-twitter me-1"></i>twitter
            </span></a>
            <br>

          data;
          }
          ?>
          <a href="<?php echo $contact_r['fb'] ?>" class="d-inline-block mb-3  text-dark">
            <span class="badge bg-light text-dark fs-6 p-2">
              <i class="bi bi-facebook me-1"></i>facebook
            </span></a>
          <br>
          <a href="<?php echo $contact_r['insta'] ?>" class="d-inline-block   text-dark">
            <span class="badge bg-light text-dark fs-6 p-2">
              <i class="bi bi-instagram me-1"></i>instagram
            </span></a>
        </div>
      </div>

    </div>
  </div>

  <!-- password reset modal -->
  <div class="modal fade" id="recoveryModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="recovery-form">
          <div class="modal-header d-flex align-item-center">
            <h5 class="modal-title"><i class="bi bi-shield-lock fs-3 me-2"></i> Set up New Password</h5>

          </div>
          <div class="modal-body">
            <div class="mb-4">
              <label class="form-label">New Password</label>
              <input type="pasword" name="pass" required class="form-control shadow-none">
              <input type="hidden" name="email">
              <input type="hidden" name="token">
            </div>
            <div class="mb-2 text-end">
              <button type="button" class="btn  shadow-none me-2" data-bs-dismiss="modal">
                CANCEL
              </button>
              <button type="submit" class="btn btn-dark shadow-none">SUBMIT</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- footer -->

  <?php require('inc/footer.php') ?>

  <?php
  if (isset($_GET['account_recovery'])) {
    $data = filteration($_GET);

    $t_date = date('Y-m-d');

    $query = select("SELECT * FROM `user_cred` WHERE `email`=? AND `token`=? AND `t_expire`=? LIMIT 1", [$data['email'], $data['token'], $t_date], 'sss');

    if (mysqli_num_rows($query) == 1) {
      echo <<<showmodal
            <script>
                var myModal = document.getElementById('recoveryModal');
                
                myModal.querySelector("input[name='email']").value='$data[email]';
                myModal.querySelector("input[name='token']").value='$data[token]';
                var modal = bootstrap.Modal.getOrCreateInstance(myModal);
                modal.show();
                
                </script>

        showmodal;
    } else {
      alert("error", "Invalid or Expired Link!");
    }
  }

  ?>


  <script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>



  <script>
    var swiper = new Swiper(".Swiper-container", {
      spaceBetween: 30,
      effect: "fade",
      loop: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,

      }

    });
    var swiper = new Swiper(".Swiper-test", {
      effect: "coverflow",
      grabCursor: true,
      centeredSlides: true,
      slidesPerView: "auto",
      slidesPerView: "3",
      loop: true,
      coverflowEffect: {
        rotate: 50,
        stretch: 0,
        depth: 100,
        modifier: 1,
        slideShadows: true,
      },
      pagination: {
        el: ".swiper-pagination",
      },
    });

    //recover account
    let recovery_form = document.getElementById('recovery-form');

    recovery_form.addEventListener('submit', (e) => {
      e.preventDefault();

      let data = new FormData();

      data.append('email', recovery_form.elements['email'].value);
      data.append('token', recovery_form.elements['token'].value);
      data.append('pass', recovery_form.elements['pass'].value);
      data.append('recover_user', '');

      var myModal = document.getElementById('recoveryModal');
      var modal = bootstrap.Modal.getInstance(myModal);
      modal.hide();

      let xhr = new XMLHttpRequest();
      xhr.open("POST", "ajax/login_register.php", true);


      xhr.onload = function() {

        if (this.responseText == 'failed') {
          alert('error', 'Account reset failed !');
        } 
        else {
          alert('success', "Account Reset Successful!");
          recovery_form.reset();
        }


      }


      xhr.send(data);
    });
  </script>
</body>

</html>