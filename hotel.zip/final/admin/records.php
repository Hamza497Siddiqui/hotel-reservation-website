<?php
require('inc/essentials.php');
require('inc/db_config.php');
adminLogin();





?>


<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Booking Records</title>
    <?php require('inc/links.php')   ?>
</head>

<body class="bg-light">

    <?php require('inc/header.php'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-10 ms-auto p-4 overflow-hidden">
                <h3 class="mb-4">BOOKING RECORDS</h3>

                <!-- section-->

                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <div class="table-responsive-md" style="height: 450px; overflow-y: scroll">
                            <table class="table table-hover border">
                                <thead class="sticky-top">
                                    <tr class="bg-dark text-light">
                                        <th scope="col">#</th>
                                        <th scope="col">Booking ID</th>
                                        <th scope="col">User ID</th>
                                        <th scope="col">Room ID</th>
                                        <th scope="col" >Room Name</th>
                                        <th scope="col">Guest Name</th>
                                        <th scope="col">Address</th>
                                        <th scope="col">Booking date</th>
                                        <th scope="col">Check-in date</th>
                                        <th scope="col">Check-out date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                        $q = "SELECT * FROM `booking` ORDER BY `date` DESC";
                                        $data = mysqli_query($con, $q);
                                        $i = 1;

                                        while ($row = mysqli_fetch_assoc($data)) {
                                            echo <<<query
                                                <tr>
                                                    <td>$i</td>
                                                    <td>$row[booking_id]</td>
                                                    <td>$row[user_id]</td>
                                                    <td>$row[room_id]</td>
                                                    <td>$row[room_name]</td>
                                                    <td>$row[name]</td>
                                                    <td>$row[address]</td>
                                                    <td>$row[date]</td>
                                                    <td>$row[check_in]</td>
                                                    <td>$row[check_out]</td>




                                                </tr>
                                                
                                                
                                                
                                                
                                                
                                                
                                                query;
                                            $i++;
                                        

                                            
                                                
                                                
                                                
                                                
                                                
                                                
                                            
                                        }


                                    ?>

                                </tbody>
                            </table>

                        </div>






                    </div>
                </div>
            </div>




            <?php require('inc/scripts.php') ?>

</body>

</html>