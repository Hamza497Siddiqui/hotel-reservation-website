<?php
 require('admin/inc/db_config.php');
 require('admin/inc/essentials.php');

 


 if(isset($_GET['confirm'])){

    $data = filteration($_GET);

    $q1 = "INSERT INTO `booking`( `user_id`, `room_id`, `room_name`, `name`, `address`, `check_in`, `check_out`) VALUES (?,?,?,?,?,?,?)";
    $values = [$data['id'],$data['room_id'],$data['room_name'],$data['name'],$data['address'],$data['checkin'],$data['checkout']];
    if(insert($q1,$values,'iisssss')){
      redirect('next.php');
        
        exit;
        
     }
    
    
 }
 









?>
<script>

</script>
