<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require('inc/links.php') ?>
    <title><?php echo $setting_r['site_title'] ?>- INVOICE</title>
</head>

<body>
    <?php require('inc/header.php');
        date_default_timezone_set("Asia/Karachi");
    ?>

    <?php



    $user_res = select("SELECT * FROM `user_cred` WHERE `id`=? LIMIT 1", [$_SESSION['uId']], "i");
    $user_data = mysqli_fetch_assoc($user_res);
    
    
    if (!(isset($_SESSION['login']) && $_SESSION['login'] == true)) {
        redirect('rooms.php');
    }
    


    ?>

    <div class="card mb-4 m-auto border-0 shadow-sm rounded-3 ">
        <div class="card-body ">
            <div class="row mt-3 " style="margin-left: 30%;">
                <h1>INVOICE:</h1>
                <div class="col ">
                    <h5>__________________________________________________________</h5>
                    <h5 class="fw-bold">ID ------------------------------------------- <span class="fw-light"><?php echo  $user_data['id']  ?> </span></h5>
                    <h5 class="fw-bold">Name ---------------------------------------- <span class="fw-light"><?php echo $user_data['name'] ?> </span></h5>
                    <h5 class="fw-bold">Dob ------------------------------------------ <span class="fw-light"><?php echo $user_data['dob'] ?> </span></h5>
                    <h5 class="fw-bold">Email ---------------------------------------- <span class="fw-light"><?php echo $user_data['email'] ?> </span></h5>
                    <h5 class="fw-bold">Phone Number ---------------------------- <span class="fw-light"><?php echo $user_data['phonenum'] ?> </span></h5>
                    <h5 class="fw-bold">Address ------------------------------------- <span class="fw-light"><?php echo $user_data['address'] ?> </span></h5>
                    <h5 class="fw-bold">Room Type ----------------------------------- <span class="fw-light"><?php echo  $_SESSION['room']['name'] ?> </span></h5>
                    <h5 class="fw-bold">Room per night ----------------------------- <span class="fw-light"><?php echo  $_SESSION['room']['price'] ?>/- </span></h5>
                    <h5 class="fw-bold">No of days ------------------------------------ <span class="fw-light"><?php echo  $_SESSION['room']['days'] ?> </span></h5>
                    <h5>__________________________________________________________</h5>
                    <h5 class="fw-bold">Registration date ------------------------------ <span class="fw-light"><?php echo date("Y-m-d") ?> </span></h5>
                    <h5 class="fw-bold">Payment ---------------------------------------- <span class="fw-light"><?php echo  $_SESSION['room']['payment'] ?>/-</span></h5>
                    <a href="" download><button style="margin-top:30px ; margin-left:28%; font-size:40px;"><i class="bi bi-printer-fill"></i></button></a>

                </div>
            </div>
        </div>
    </div>
    <?php require('inc/footer.php') ?>




</body>


</html>